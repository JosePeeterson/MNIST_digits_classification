This file includes following parts:

c) (2) polynomial regression

Instructions:

1) run the program to findout accuracy