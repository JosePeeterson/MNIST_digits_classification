
import os
import struct
import numpy as np
from numpy import linalg as LA
from sklearn.preprocessing import StandardScaler

    # Function defitions

def Find_mean_vector(data):
    "This function calculates the mean vector from the data matrix (CA2 part b)"
    # CA2 part b
    # declare list of 784 x 1 zeros vector
    sum_col_maj_pixels = [[0] for i in range(len(data[0]))]
    # convert list to numpy matrix
    sum_col_maj_pixels = np.matrix(sum_col_maj_pixels)

    for i in range(len(data)):
        temp = np.matrix(data[i][:])
        temp = np.transpose(temp)
        sum_col_maj_pixels = np.add(sum_col_maj_pixels, temp)

    # mean digit vector calculated by dividing by total number of data
    mean_digit_vector = sum_col_maj_pixels/len(data)
    mean_digit_vector = np.matrix(mean_digit_vector)
    return mean_digit_vector



# MAIN Program

# Test and Train image and label Extraction code
# load the train and test image data and labels into matrices
FILES_DIR = '.\\MNIST_Data\\'
TRAIN_FILE = 'train-images.idx3-ubyte'
TRAIN_LABEL = 'train-labels.idx1-ubyte'
TEST_FILE = 't10k-images.idx3-ubyte'
TEST_LABEL = 't10k-labels.idx1-ubyte'

with open(FILES_DIR + TRAIN_FILE, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    trainingData=datatemp[16::].reshape(60000,784)
    #print('size of the training set: ', len(trainingData))

with open(FILES_DIR + TRAIN_LABEL, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    trainingLabels=datatemp[8::]
    #print('size of the training labels: ', trainingLabels.shape)

with open(FILES_DIR + TEST_FILE, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    testData=datatemp[16::].reshape(10000,784)
    #print('size of the test set: ', testData.shape)

with open(FILES_DIR + TEST_LABEL, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    testLabels=datatemp[8::]
    #print('size of the test labels: ', testLabels.shape)

# Standardize features by removing the mean and scaling to unit variance
trainingData = StandardScaler().fit_transform (trainingData)
testData = StandardScaler().fit_transform (testData)

# calculate the mean of the training data
mean_digit_vector = Find_mean_vector(trainingData)
print('shape',mean_digit_vector.shape)
print('element 250',mean_digit_vector[250])
print('element 303',mean_digit_vector[303])










