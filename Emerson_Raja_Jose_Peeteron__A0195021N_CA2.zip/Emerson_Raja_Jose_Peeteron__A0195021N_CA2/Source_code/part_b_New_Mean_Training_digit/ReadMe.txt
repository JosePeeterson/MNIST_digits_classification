This file includes following parts:

Mean of the training digits

Instructions:

1) just run the code.