This file includes following parts:

Covariance matrix
Visualize the Eigenvectors
Image reconstruction (1)
Image reconstruction (2)

Instructions:

1) To visualize the eigenvectors, uncomment line 116 (#show(pixels)) and run the program
2) To Image reconstruction (1), comment line 116, uncomment line 124 (#show(pxls)) and run the program
3) To Image reconstruction (2), comment line 124, uncomment line 152 (#show(show_reconstruct_img)) and run the program

