
import os
import struct
import numpy as np
from numpy import linalg as LA
from sklearn.preprocessing import StandardScaler

        # Function defitions

def show(image):
    "Function to display image of the digit on a 28x28 pixel display"
    from matplotlib import pyplot
    import matplotlib as mpl
    fig = pyplot.figure()
    ax = fig.add_subplot(1, 1, 1)
    imgplot = ax.imshow(image,cmap=mpl.cm.Greys)
    imgplot.set_interpolation('nearest')
    ax.xaxis.set_ticks_position('top')
    ax.yaxis.set_ticks_position('left')
    pyplot.show()



def Find_mean_vector(data):
    "This function calculates the mean vector from the data matrix (CA2 part b)"
    # CA2 part b
    # declare list of 784 x 1 zeros vector
    sum_col_maj_pixels = [[0] for i in range(len(data[0]))]
    # convert list to numpy matrix
    sum_col_maj_pixels = np.matrix(sum_col_maj_pixels)

    for i in range(len(data)):
        temp = np.matrix(data[i][:])
        temp = np.transpose(temp)
        sum_col_maj_pixels = np.add(sum_col_maj_pixels, temp)

    # mean digit vector calculated by dividing by total number of data
    mean_digit_vector = sum_col_maj_pixels/len(data)
    mean_digit_vector = np.matrix(mean_digit_vector)
    return mean_digit_vector



def Find_cov_matrix(mean_vector,data):
    "This fucntion finds the covariance matrix as per equation 13 in week 3 lectures (CA2 part b)"
    # convert to numpy array
    mean_vector = np.array (mean_vector, dtype=np.float64)
    mean_vector = np.transpose(mean_vector)
    mean_vector = np.array(mean_vector)
    # convert to numpy array
    data = np.array(data)
    # carryout mean center of all the data points
    mean_ctr_data = data - mean_vector
    mean_ctr_data = np.array(mean_ctr_data)
    # transpose
    mean_ctr_data_trps = np.transpose(mean_ctr_data)
    # create covariance matrix using matrix multiplication for faster performance
    cov_matrix = np.dot(mean_ctr_data_trps,mean_ctr_data)
    cov_matrix = cov_matrix / len(data)
    return cov_matrix




        # MAIN Program

# Test and Train image and label Extraction code
# load the train and test image data and labels into matrices
FILES_DIR = '.\\MNIST_Data\\'
TRAIN_FILE = 'train-images.idx3-ubyte'
TRAIN_LABEL = 'train-labels.idx1-ubyte'
TEST_FILE = 't10k-images.idx3-ubyte'
TEST_LABEL = 't10k-labels.idx1-ubyte'

with open(FILES_DIR + TRAIN_FILE, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    trainingData=datatemp[16::].reshape(60000,784)
    #print('size of the training set: ', len(trainingData))

with open(FILES_DIR + TRAIN_LABEL, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    trainingLabels=datatemp[8::]
    #print('size of the training labels: ', trainingLabels.shape)

with open(FILES_DIR + TEST_FILE, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    testData=datatemp[16::].reshape(10000,784)
    #print('size of the test set: ', testData.shape)

with open(FILES_DIR + TEST_LABEL, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    testLabels=datatemp[8::]
    #print('size of the test labels: ', testLabels.shape)

# Standardize features by removing the mean and scaling to unit variance
trainingData = StandardScaler().fit_transform (trainingData)
testData = StandardScaler().fit_transform (testData)

# calculate the mean of the training data
mean_digit_vector = Find_mean_vector(trainingData)

# calcualte 784 x 784 covariance matrix
cov_matrix = Find_cov_matrix(mean_digit_vector,trainingData)
cov_matrix = np.array (cov_matrix, dtype=np.float64)

# Eigen decomposition to compute 784 eigenvalues and eigenvectors
eig_val, eig_vector =  LA.eigh(cov_matrix)
eig_vector = np.array (eig_vector, dtype=np.float64)


# visualizing the 10 largest eigenvectors using show function
# eig_Val is in ascending order so we have to work backwards to get the largest to smallest 10 eigenvectors.
for e in range(len(eig_val) - 1, len(eig_val) - 11 ,-1):
    pxls = np.array(eig_vector[:,e])
    pixels = pxls.reshape(28,28)
    #show(pixels)

# part b) (1) just showing of first row of training images
for n in range(2,22,2):
    # in Python array indexing subtracts one as it goes from 0 to len - 1
    pixels = trainingData[n-1][:]
    pixels = np.array(pixels)
    pxls = pixels.reshape(28, 28)
    #show(pxls)

# part b) (2) reconstructed images form the test set digits 0 - 9
# list of the indices of test images to be reconstructed
test_img = [4,3,2,19,5,9,12,1,62,8]

for img in test_img:
    # declare lambda vector
    lamb = np.zeros(30)
    # reconstructed data point, declare 784 x 1 array to assign the reconstrcted pixels later
    img_reconstruct = np.zeros(len(testData[0]))
    img_reconstruct = np.array(img_reconstruct)
    # pick the test digit from the array
    tst_pixels = np.array(testData[img-1][:])
    tst_pixels = np.array (tst_pixels, dtype=np.float64)

    # reconstruct using the top 30 eigenvectors
    # eig_Val is in ascending order so we have to work backwards to get the largest to smallest 30 eigenvectors.
    for e in range(len(eig_val) - 1, len(eig_val) - 31, -1):
        # calculate the 30 lambda values in one step
        lamb = np.dot(tst_pixels, eig_vector[:, e])
        eig_vec_temp = np.array(eig_vector[:, e])
        eig_vec_temp = np.multiply(eig_vec_temp,lamb) #vector: 784
        # reconstructed data point,
        img_reconstruct = img_reconstruct + eig_vec_temp

    # display the image on a 28 x 28 pixel display
    show_reconstruct_img = img_reconstruct.reshape(28, 28)
    #show(show_reconstruct_img)








