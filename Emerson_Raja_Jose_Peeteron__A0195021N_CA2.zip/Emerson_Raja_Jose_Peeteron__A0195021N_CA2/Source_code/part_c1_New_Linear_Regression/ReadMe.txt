This file includes following parts:

c) Eigen_digits
c) (1) Linear regression

Instructions:

1) run the program to get testing accuracy.