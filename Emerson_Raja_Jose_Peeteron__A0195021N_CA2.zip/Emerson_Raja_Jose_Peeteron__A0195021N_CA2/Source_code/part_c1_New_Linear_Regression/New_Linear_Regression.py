
import os
import struct
import numpy as np
from numpy import linalg as LA
from sklearn.preprocessing import StandardScaler

        # Function defitions

def Find_mean_vector(data):
    "This function calculates the mean vector from the data matrix (CA2 part b)"
    # CA2 part b
    # declare list of 784 x 1 zeros vector
    sum_col_maj_pixels = [[0] for i in range(len(data[0]))]
    # convert list to numpy matrix
    sum_col_maj_pixels = np.matrix(sum_col_maj_pixels)

    for i in range(len(data)):
        temp = np.matrix(data[i][:])
        temp = np.transpose(temp)
        sum_col_maj_pixels = np.add(sum_col_maj_pixels, temp)

    # mean digit vector calculated by dividing by total number of data
    mean_digit_vector = sum_col_maj_pixels/len(data)
    mean_digit_vector = np.matrix(mean_digit_vector)
    return mean_digit_vector



def Find_cov_matrix(mean_vector,data):
    "This fucntion finds the covariance matrix as per equation 13 in week 3 lectures (CA2 part b)"
    # convert to numpy array
    mean_vector = np.array (mean_vector, dtype=np.float64)
    mean_vector = np.transpose(mean_vector)
    mean_vector = np.array(mean_vector)
    # convert to numpy array
    data = np.array(data)
    # carryout mean center of all the data points
    mean_ctr_data = data - mean_vector
    mean_ctr_data = np.array(mean_ctr_data)
    # transpose
    mean_ctr_data_trps = np.transpose(mean_ctr_data)
    # create covariance matrix using matrix multiplication for faster performance
    cov_matrix = np.dot(mean_ctr_data_trps,mean_ctr_data)
    cov_matrix = cov_matrix / len(data)
    return cov_matrix



def mean_center_eigen_project(mean_vector,trainingData,testData,larg_eig_Vector_mat):
    "This function 'mean centers' and calculates 'projected eigenvalues' (CA2 part c)"
    mean_vector = np.array (mean_vector, dtype=np.float64)
    mean_vector = np.transpose(mean_vector)

    # convert to numpy array
    trainingData = np.array(trainingData)
    testData = np.array(testData)

    # subtract the mean vector from entire matrix of training data
    mean_ctr_trainingData = trainingData - mean_vector
    mean_ctr_trainingData = np.array(mean_ctr_trainingData)

    # subtract the mean vector from entire matrix of testing data
    mean_ctr_testData = testData - mean_vector
    mean_ctr_testData = np.array(mean_ctr_testData)
    #print(mean_ctr_testData.shape)

    # declare zero arrays to house projected test and training data in 30 dimensional eigenvector subspace
    proj_trainingData = np.zeros((60000,30),dtype=np.float64)
    proj_testData = np.zeros((10000, 30), dtype=np.float64)

    # compute the 30 dimensional projected eigenvalues for training data
    for x in range(len(trainingData)):
        lamb_trn = np.dot(trainingData[x],larg_eig_Vector_mat)
        proj_trainingData[x] = np.array(lamb_trn,dtype=np.float64)

    # compute the 30 dimensional projected eigenvalues for testing data
    for y in range(len(testData)):
        lamb_test = np.dot(testData[y],larg_eig_Vector_mat)
        proj_testData[y] = np.array(lamb_test,dtype=np.float64)

    return proj_trainingData,proj_testData



def linear_regression_accuracy(proj_trainingData, proj_testData, trainingLabels, testLabels):

    trn_ones_col = np.ones((60000,1),dtype=np.float64)
    test_ones_col = np.ones((10000, 1), dtype=np.float64)

    # training data matrix with first column appended with vector of ones for bias term.
    y_trn_data = np.concatenate((trn_ones_col,proj_trainingData),axis=1)
    # test data matrix with first column appended with vector of ones for bias term.
    y_test_data = np.concatenate((test_ones_col,proj_testData),axis=1)
    #print(y_trn_data.shape)
    #print(y_trn_data[5999][0])

    # matrix with row vector of one and zeros with one correspoinding to correct class at that index
    # there are 10 class labels
    b_trn_margin_mat = np.zeros((len(proj_trainingData),10),dtype=int)

    # assign a 1 to the correct class index 0 - 9 in the B matrix for all training data points
    for x in range(len(proj_trainingData)):
        b_trn_margin_mat[x][trainingLabels[x]] = 1

    # implement equation 36 in lecture 8 to find matrix A
    y_trn_data_trans = np.transpose(y_trn_data)
    y_trn_data_temp = np.dot(y_trn_data_trans,y_trn_data)
    y_trn_data_temp = LA.inv(y_trn_data_temp)
    y_trn_data_pseudo = np.dot(y_trn_data_temp,y_trn_data_trans)
    a_weights_mat = np.dot(y_trn_data_pseudo,b_trn_margin_mat)
    #print(a_weights_mat.shape)

    # Evaluate/predict for test data
    # correct_class coutns how many are classified correctly
    correct_class = 0
    #prediction = np.zeros((10000, 1), dtype=int)
    for i in range(len(proj_testData)):
        predicted_class = np.dot((np.transpose(a_weights_mat)),np.transpose(y_test_data[i]))
        # pick the digit the largest discrimnant value g(x)
        prediction = predicted_class.argmax()
        # compare with test labels
        if prediction == testLabels[i]:
            correct_class = correct_class + 1

    # percentage of classification accuracy
    classification_acc = (correct_class/len(proj_testData))*100

    return classification_acc



        # MAIN Program

# Test and Train image and label Extraction code
# load the train and test image data and labels into matrices
FILES_DIR = '.\\MNIST_Data\\'
TRAIN_FILE = 'train-images.idx3-ubyte'
TRAIN_LABEL = 'train-labels.idx1-ubyte'
TEST_FILE = 't10k-images.idx3-ubyte'
TEST_LABEL = 't10k-labels.idx1-ubyte'

with open(FILES_DIR + TRAIN_FILE, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    trainingData=datatemp[16::].reshape(60000,784)
    #print('size of the training set: ', len(trainingData))

with open(FILES_DIR + TRAIN_LABEL, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    trainingLabels=datatemp[8::]
    #print('size of the training labels: ', trainingLabels.shape)

with open(FILES_DIR + TEST_FILE, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    testData=datatemp[16::].reshape(10000,784)
    #print('size of the test set: ', testData.shape)

with open(FILES_DIR + TEST_LABEL, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    testLabels=datatemp[8::]
    #print('size of the test labels: ', testLabels.shape)

# Standardize features by removing the mean and scaling to unit variance
trainingData = StandardScaler().fit_transform (trainingData)
testData = StandardScaler().fit_transform (testData)

# calculate the mean of the training data
mean_digit_vector = Find_mean_vector(trainingData)

# calcualte 784 x 784 covariance matrix
cov_matrix = Find_cov_matrix(mean_digit_vector,trainingData)
cov_matrix = np.array (cov_matrix, dtype=np.float64)

# Eigen decomposition to compute 784 eigenvalues and eigenvectors
eig_val, eig_vector =  LA.eigh(cov_matrix)
eig_vector = np.array(eig_vector, dtype=np.float64)

# creating a new subarray of 30 largest eigen vectors in SMALLEST TO LARGEST eigenvalue order
# note indexing does not include 784. It goes up to 783, so 754 + 29 = 783 which is 30 eigenvalues (including 754) in total.
larg_eig_Vector_mat = eig_vector[:,754:784]
larg_eig_Vector_mat = np.array(larg_eig_Vector_mat, dtype=np.float64)

# part c, mean cener and projected eigenvalues
proj_trainingData,proj_testData = mean_center_eigen_project(mean_digit_vector,trainingData,testData,larg_eig_Vector_mat)

# part c (1)
# linear discriminant functions for classification
lin_reg_clas_acc = linear_regression_accuracy(proj_trainingData, proj_testData, trainingLabels, testLabels)
print("Classification accuracy of linear discriminant function is", lin_reg_clas_acc,"%")

