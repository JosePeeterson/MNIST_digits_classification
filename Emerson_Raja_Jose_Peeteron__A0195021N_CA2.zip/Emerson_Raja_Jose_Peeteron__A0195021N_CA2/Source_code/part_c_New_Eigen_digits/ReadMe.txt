This file includes following parts:

c) Eigen_digits

Instructions:

1) Run the program to print out the shape of projected training and test data.