This file includes following parts:

d) linear + 2nd degree polynomial terms
d) linear + 3rd degree polynomial terms
d) linear + 2nd and 3rd degree polynomial terms

Instructions:

1) run the program to get the classification accuracy.