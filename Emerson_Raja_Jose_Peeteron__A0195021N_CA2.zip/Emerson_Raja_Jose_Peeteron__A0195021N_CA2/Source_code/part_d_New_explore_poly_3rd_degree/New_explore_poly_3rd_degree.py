
import os
import struct
import numpy as np
from numpy import linalg as LA
from sklearn.preprocessing import StandardScaler
from itertools import combinations_with_replacement

        # Function definitions

def Find_mean_vector(data):
    "This function calculates the mean vector from the data matrix (CA2 part b)"
    # CA2 part b
    # declare list of 784 x 1 zeros vector
    sum_col_maj_pixels = [[0] for i in range(len(data[0]))]
    # convert list to numpy matrix
    sum_col_maj_pixels = np.matrix(sum_col_maj_pixels)

    # extract rows of feature vectors and sum them together
    for i in range(len(data)):
        temp = np.matrix(data[i][:])
        temp = np.transpose(temp)
        sum_col_maj_pixels = np.add(sum_col_maj_pixels, temp)

    # mean digit vector calculated by dividing by total number of data
    mean_digit_vector = sum_col_maj_pixels/len(data)
    mean_digit_vector = np.matrix(mean_digit_vector)
    return mean_digit_vector



def Find_cov_matrix(mean_vector,data):
    "This fucntion finds the covariance matrix as per equation 13 in week 3 lectures (CA2 part b)"
    # convert to numpy array
    mean_vector = np.array (mean_vector, dtype=np.float64)
    mean_vector = np.transpose(mean_vector)
    mean_vector = np.array(mean_vector)
    # convert to numpy array
    data = np.array(data)
    # carryout mean center of all the data points
    mean_ctr_data = data - mean_vector
    mean_ctr_data = np.array(mean_ctr_data)
    # transpose
    mean_ctr_data_trps = np.transpose(mean_ctr_data)
    # create covariance matrix using matrix multiplication for faster performance
    cov_matrix = np.dot(mean_ctr_data_trps,mean_ctr_data)
    cov_matrix = cov_matrix / len(data)
    return cov_matrix



def mean_center_eigen_project(mean_vector,trainingData,testData,larg_eig_Vector_mat):
    "This function 'mean centers' and calculates 'projected eigenvalues' (CA2 part c)"
    mean_vector = np.array (mean_vector, dtype=np.float64)
    mean_vector = np.transpose(mean_vector)

    # convert to numpy array
    trainingData = np.array(trainingData)
    testData = np.array(testData)

    # subtract the mean vector from entire matrix of training data
    mean_ctr_trainingData = trainingData - mean_vector
    mean_ctr_trainingData = np.array(mean_ctr_trainingData)

    # subtract the mean vector from entire matrix of testing data
    mean_ctr_testData = testData - mean_vector
    mean_ctr_testData = np.array(mean_ctr_testData)

    # declare zero arrays to house projected test and training data in 30 dimensional eigenvector subspace
    proj_trainingData = np.zeros((60000,30),dtype=np.float64)
    proj_testData = np.zeros((10000, 30), dtype=np.float64)

    # compute the 30 dimensional projected eigenvalues for training data
    for x in range(len(trainingData)):
        lamb_trn = np.dot(trainingData[x],larg_eig_Vector_mat)
        proj_trainingData[x] = np.array(lamb_trn,dtype=np.float64)

    # compute the 30 dimensional projected eigenvalues for testing data
    for y in range(len(testData)):
        lamb_test = np.dot(testData[y],larg_eig_Vector_mat)
        proj_testData[y] = np.array(lamb_test,dtype=np.float64)

    return proj_trainingData,proj_testData



def generate_poly_terms(poly_order,comb,proj_Data):
    "This fucntion forms the data polynomial terms matrix for 2nd and/or 3rd order poly terms (CA2 part c (2) & d )"
    # row vector of polynomial terms for a single data point that needs to be concatenated to linear terms
    poly_terms = np.array((), dtype=np.float64)
    # matrix of polynomial terms for all training data 60000 x 465 and testing 10000 x 465
    poly_mat = np.zeros((len(proj_Data), len(comb)),dtype=np.float64)

    # calcualte 2nd order polynomial terms
    if poly_order == 2:
        # indices i and j are list of combination values representing polynomial terms indices, comb[][0] and comb[][1]
        i = np.array([])
        j = np.array([])
        for n in range(len(comb)):
            i = np.append(i, comb[n][0])
            j = np.append(j, comb[n][1])
        i = np.array(i, int)
        j = np.array(j, int)

        # formation of the data polynomial terms matrix
        for k in range(len(proj_Data)):
            # form a row vector of polynomial terms, note only two terms multiply so its 2nd degree
            # number of monomial terms for degree 2 is 465
            poly_terms = proj_Data[k][i[0:465]] * proj_Data[k][j[0:465]]
            poly_terms = np.array(poly_terms)
            # fill the polynomial matrix with row vector for each row
            poly_mat[k] = poly_terms

        return poly_mat

    # only the 3rd order polynomilal terms are included, the 2nd order terms are excluded.
    elif poly_order == 3:

        # indices i and j are list of combination values representing polynomial terms indices, comb[][0] and comb[]
        h = np.array([])
        i = np.array([])
        j = np.array([])
        for n in range(len(comb)):
            h = np.append(h, comb[n][0])
            i = np.append(i, comb[n][1])
            j = np.append(j, comb[n][2])
        h = np.array(h, int)
        i = np.array(i, int)
        j = np.array(j, int)

        # number of monomial terms is d
        d = len(comb)
        # formation of the data polynomial terms matrix
        for k in range(len(proj_Data)):
            # form a row vector of polynomial terms
            poly_terms = proj_Data[k][h[0:d]] * proj_Data[k][i[0:d]] * proj_Data[k][j[0:d]]
            poly_terms = np.array(poly_terms)
            # fill the polynomial matrix with row vector for each row
            poly_mat[k] = poly_terms

        return  poly_mat

    # poly_order == 4 includes 2nd order and 3rd order polynomial terms together with linear terms
    elif poly_order == 4:

        # dim is a list of numbers from 1 to dimension,d (30) of the input
        dim = np.arange(0, len(proj_Data[0]))
        # comb is a tuple of pairs like [(1,1) (1,2) (1, 3)....(d, d)]
        # combination of monomial terms for order 2
        comb2 = list(combinations_with_replacement(dim, 2))
        # combination of monomial terms for order 3
        comb3 = list(combinations_with_replacement(dim, 3))
        # matrix of second order monomial terms
        poly_mat_two = np.zeros((len(proj_Data), len(comb2)), dtype=np.float64)
        # matrix of third order monomial terms
        poly_mat_three = np.zeros((len(proj_Data), len(comb3)), dtype=np.float64)

        # matrix of linear + 2nd order + 3rd order polynomial terms
        poly_mat_four = np.zeros((len(proj_Data), len(comb2) + len(comb3)), dtype=np.float64)

        # matrix of 2nd order polynomial terms only
        poly_mat_two = generate_poly_terms(2, comb2, proj_Data)
        # matrix of 3rd order polynomial terms
        poly_mat_three = generate_poly_terms(3, comb3, proj_Data)
        # concatenate 2nd adn 3rd order terms
        poly_mat_four = np.concatenate((poly_mat_two,poly_mat_three), axis=1)

        return  poly_mat_four




def polynomial_regression_accuracy(proj_trainingData, proj_testData, trainingLabels, testLabels,poly_order):
    "This function computes classification accuracy of differnt order of polynomial discriminant function (CA2 part d )"
    # The number of monomial terms in a polynomial discriminant function of dimension 'd' and order 'o' is given by:
    # 1 (bias term) + d (linear terms) + comb (non-linear terms)
    # the first two terms 1 + d comes from the linear discriminant function
    # the next term comb comes from the non-linear portion
    # the function combinations_with_replacement provides the combinations for the last two terms.

    # training data

    # proj_trainingData is a 60000 x 30 matrix without the ones column for bias term
    # dim is a list of numbers from 1 to dimension,d (30) of the input
    dim = np.arange(0,len(proj_trainingData[0]))
    # comb is a tuple of pairs or cubes like [(1,1) (1,2) (1, 3)....(d, d)] [(1,1,1) (1,1,2) .....)]
    comb = list(combinations_with_replacement(dim, poly_order))
    # matrix of polynomial terms for all training data 60000 x 465
    trn_poly_mat = np.zeros((len(proj_trainingData), len(comb)),dtype=np.float64)

    if poly_order == 4:
        # number of polynomial terms for order 2
        comb2 = list(combinations_with_replacement(dim, 2))
        # number of polynomial terms for order 3
        comb3 = list(combinations_with_replacement(dim, 3))
        # declare a matrix of zeros with both 2nd and 3rd order terms combined
        trn_poly_mat = np.zeros((len(proj_trainingData), len(comb2) + len(comb3)), dtype=np.float64)
        # generate_poly_terms function makes maxtrix of 2nd and 3rd order poly terms
        # note: comb argument is meaningless here and its not used for poly_order = 4 inside this function
        trn_poly_mat = generate_poly_terms(poly_order, comb, proj_trainingData)

        trn_ones_col = np.ones((60000, 1), dtype=np.float64)
        # combine linear and 2nd and 3rd order terms into a single matrix
        y_trn_data = np.concatenate((trn_ones_col, proj_trainingData), axis=1)
        y_trn_data = np.concatenate((y_trn_data, trn_poly_mat), axis=1)

    # if poly_order is 2 or 3 then do the following
    else:
        # formation of the data polynomial terms matrix
        trn_poly_mat = generate_poly_terms(poly_order, comb, proj_trainingData)
        # column of ones to be appended to proj_trainingData matrix
        trn_ones_col = np.ones((60000, 1), dtype=np.float64)
        # combine linear and 2nd or 3rd order terms into a single matrix
        # training data matrix with first column appended with vector of ones for bias term. 60000 x 31
        y_trn_data = np.concatenate((trn_ones_col, proj_trainingData), axis=1)
        # concatenate the linear terms matrix and polynomial matrix
        y_trn_data = np.concatenate((y_trn_data, trn_poly_mat), axis=1)

    # matrix with row vector of one and zeros with one correspoinding to correct class at that index
    # there are 10 class labels
    b_trn_margin_mat = np.zeros((len(proj_trainingData), 10), dtype=int)

    # assign a 1 to the correct class index 0 - 9 in the B matrix for all training data points
    for x in range(len(proj_trainingData)):
        b_trn_margin_mat[x][trainingLabels[x]] = 1

    # implement equation 36 in lecture 8 to find matrix A
    y_trn_data_trans = np.transpose(y_trn_data)
    y_trn_data_temp = np.dot(y_trn_data_trans, y_trn_data)
    y_trn_data_temp = LA.inv(y_trn_data_temp)
    y_trn_data_pseudo = np.dot(y_trn_data_temp, y_trn_data_trans)
    a_weights_mat = np.dot(y_trn_data_pseudo, b_trn_margin_mat)

    # testing data

    if poly_order ==4:
        # number of polynomial terms for order 2
        comb2 = list(combinations_with_replacement(dim, 2))
        # number of polynomial terms for order 3
        comb3 = list(combinations_with_replacement(dim, 3))
        # declare a matrix of zeros with both 2nd and 3rd order terms combined
        test_poly_mat = np.zeros((len(proj_testData), len(comb2) + len(comb3)), dtype=np.float64)
        # note comb argument is meaningless and its not used for poly_order = 4
        test_poly_mat = generate_poly_terms(poly_order, comb, proj_testData)

        test_ones_col = np.ones((10000, 1), dtype=np.float64)
        # combine linear and 2nd and 3rd order terms into a single matrix
        y_test_data = np.concatenate((test_ones_col, proj_testData), axis=1)
        y_test_data = np.concatenate((y_test_data, test_poly_mat), axis=1)

    else:
        # column of ones to be appended to proj_testData matrix
        test_ones_col = np.ones((10000, 1), dtype=np.float64)
        # matrix of polynomial terms for all testing data 10000 x 465
        test_poly_mat = np.zeros((len(proj_testData), len(comb)),dtype=np.float64)

        # formation of the data polynomial terms matrix
        test_poly_mat = generate_poly_terms(poly_order, comb, proj_testData)

        # test data matrix with first column appended with vector of ones for bias term. 10000 x 31
        y_test_data = np.concatenate((test_ones_col, proj_testData), axis=1)
        # concatenate the linear terms matrix and polynomial matrix
        y_test_data = np.concatenate((y_test_data, test_poly_mat), axis=1)

    # Evaluate/predict for test data
    # correct_class coutns how many are classified correctly
    correct_class = 0
    for t in range(len(proj_testData)):
        predicted_class = np.dot((np.transpose(a_weights_mat)),np.transpose(y_test_data[t]))
        # pick the digit the largest discrimnant value g(x)
        prediction = predicted_class.argmax()
        # compare with test labels
        if prediction == testLabels[t]:
            correct_class = correct_class + 1

    # percentage of classification accuracy
    classification_acc = (correct_class/len(proj_testData))*100

    return  classification_acc





        # MAIN Program

# Test and Train image and label Extraction code
# load the train and test image data and labels into matrices
FILES_DIR = '.\\MNIST_Data\\'
TRAIN_FILE = 'train-images.idx3-ubyte'
TRAIN_LABEL = 'train-labels.idx1-ubyte'
TEST_FILE = 't10k-images.idx3-ubyte'
TEST_LABEL = 't10k-labels.idx1-ubyte'

with open(FILES_DIR + TRAIN_FILE, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    trainingData=datatemp[16::].reshape(60000,784)
    #print('size of the training set: ', len(trainingData))

with open(FILES_DIR + TRAIN_LABEL, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    trainingLabels=datatemp[8::]
    #print('size of the training labels: ', trainingLabels.shape)

with open(FILES_DIR + TEST_FILE, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    testData=datatemp[16::].reshape(10000,784)
    #print('size of the test set: ', testData.shape)

with open(FILES_DIR + TEST_LABEL, 'rb') as ftemp:
    datatemp = np.fromfile(ftemp,dtype=np.ubyte)
    testLabels=datatemp[8::]
    #print('size of the test labels: ', testLabels.shape)

# Standardize features by removing the mean and scaling to unit variance
trainingData = StandardScaler().fit_transform (trainingData)
testData = StandardScaler().fit_transform (testData)

# calculate the mean of the training data
mean_digit_vector = Find_mean_vector(trainingData)

# calcualte 784 x 784 covariance matrix
cov_matrix = Find_cov_matrix(mean_digit_vector,trainingData)
cov_matrix = np.array (cov_matrix, dtype=np.float64)

# Eigen decomposition to compute 784 eigenvalues and eigenvectors
eig_val, eig_vector =  LA.eigh(cov_matrix)
eig_vector = np.array(eig_vector, dtype=np.float64)

# creating a new subarray of 30 largest eigen vectors in SMALLEST TO LARGEST eigenvalue order
# note indexing does not include 784. It goes up to 783, so 754 + 29 = 783 which is 30 eigenvalues in total.
larg_eig_Vector_mat = eig_vector[:,754:784]
larg_eig_Vector_mat = np.array(larg_eig_Vector_mat, dtype=np.float64)

# part c, mean cener and projected eigenvalues
proj_trainingData,proj_testData = mean_center_eigen_project(mean_digit_vector,trainingData,testData,larg_eig_Vector_mat)

# part c (2) and d
# order of polynomial terms e.g. 2 = only  linear terms + only 2nd order terms
# 3 = linear terms + only 3rd order terms
# 4 = linear terms + both 2nd and 3rd order terms combined
# order is just for printing purpose
order = ['2nd','3rd','2nd and 3rd']
# polynomial_order list to iterate through the 3 cases
polynomial_order = [2, 3, 4]
for poly_order in polynomial_order:
    # calculates accuracy of polynomial order terms
    classification_acc = polynomial_regression_accuracy(proj_trainingData, proj_testData, trainingLabels, testLabels,poly_order)
    print("Classification accuracy of linear plus",order[poly_order-2], "order polynomial is", classification_acc,"%")





