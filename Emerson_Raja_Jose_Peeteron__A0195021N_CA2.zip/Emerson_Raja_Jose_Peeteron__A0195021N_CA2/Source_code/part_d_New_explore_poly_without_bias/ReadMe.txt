This file includes following parts:

d) linear + 2nd degree polynomial without bias

Instructions:

1) RUn the code to get classification accuracy.