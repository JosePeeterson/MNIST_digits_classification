This file includes following parts:

d) Linear regression with higher dimensions (> 30) for projected eigenvalues

Instructions:

1) adjust the eig_dim variable at line 179 to choose the top no. of eigenvectors. e.g. eig_dim = 30 then run the program
